import express from 'express';
import aiController from '../controllers/aiController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

// Public routes
router.get('/options', aiController.getAllOptions);
router.get('/options/:category', aiController.getOptionsByCategory);
router.get('/export', aiController.exportOptions);

// Protected routes (cần đăng nhập để thêm/xóa options)
router.post('/discover-options', protect, aiController.discoverOptions);
router.delete('/options/:id', protect, aiController.deleteOption);

export default router;
