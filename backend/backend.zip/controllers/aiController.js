import FashionOption from '../models/FashionOption.js';

// POST /api/ai/discover-options - AI tự thêm options mới vào DB
export const discoverOptions = async (req, res) => {
  try {
    const { options } = req.body; // [{ category: 'scene', value: 'rooftop garden' }]
    
    if (!options || !Array.isArray(options)) {
      return res.status(400).json({ message: 'Options array required' });
    }

    const results = await FashionOption.bulkUpsert(options);
    
    const newOptions = results
      .filter(r => r.success)
      .map(r => ({ category: r.option.category, value: r.option.value }));
    
    res.json({
      message: `Discovered ${newOptions.length} new options`,
      newOptions,
      allResults: results
    });
  } catch (error) {
    console.error('Discover options error:', error);
    res.status(500).json({ message: error.message });
  }
};

// GET /api/ai/options/:category - Lấy options theo category
export const getOptionsByCategory = async (req, res) => {
  try {
    const { category } = req.params;
    const options = await FashionOption.find({ category, isActive: true })
      .sort({ usageCount: -1, createdAt: -1 });
    
    res.json(options);
  } catch (error) {
    console.error('Get options error:', error);
    res.status(500).json({ message: error.message });
  }
};

// GET /api/ai/options - Lấy tất cả options
export const getAllOptions = async (req, res) => {
  try {
    const options = await FashionOption.find({ isActive: true })
      .sort({ category: 1, usageCount: -1 });
    
    // Group by category
    const grouped = options.reduce((acc, opt) => {
      if (!acc[opt.category]) {
        acc[opt.category] = [];
      }
      acc[opt.category].push(opt);
      return acc;
    }, {});
    
    res.json(grouped);
  } catch (error) {
    console.error('Get all options error:', error);
    res.status(500).json({ message: error.message });
  }
};

// DELETE /api/ai/options/:id - Xóa option
export const deleteOption = async (req, res) => {
  try {
    await FashionOption.findByIdAndUpdate(req.params.id, { isActive: false });
    res.json({ message: 'Option deleted' });
  } catch (error) {
    console.error('Delete option error:', error);
    res.status(500).json({ message: error.message });
  }
};

// GET /api/ai/export - Export options cho training
export const exportOptions = async (req, res) => {
  try {
    const options = await FashionOption.find({ isActive: true })
      .select('category value isAIGenerated usageCount createdAt -_id');
    
    res.json({
      exportDate: new Date().toISOString(),
      totalOptions: options.length,
      data: options
    });
  } catch (error) {
    console.error('Export options error:', error);
    res.status(500).json({ message: error.message });
  }
};

export default {
  discoverOptions,
  getOptionsByCategory,
  getAllOptions,
  deleteOption,
  exportOptions
};
