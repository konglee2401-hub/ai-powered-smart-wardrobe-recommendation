import { GoogleGenerativeAI } from '@google/generative-ai';
import axios from 'axios';

let genAI = null;
const getGenAI = () => {
  if (!genAI) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error('GEMINI_API_KEY missing');
    genAI = new GoogleGenerativeAI(apiKey);
  }
  return genAI;
};

const getVisionPrompt = () => 'Fashion JSON: description,hair_style,hair_acc,makeup,top_detail,material,outerwear,bottom_type,legwear,necklace,earrings,hand_acc,waist_acc,shoes,scene,lighting,expression,style';

const parseJsonResponse = (text) => {
  const m = text.match(/\{[\s\S]*\}/);
  return JSON.parse(m ? m[0] : text);
};

const analyzeWithGemini = async (img, mime, opts) => {
  const model = getGenAI().getGenerativeModel({ model: 'gemini-2.5-flash' });
  const part = { inlineData: { data: img, mimeType: mime || 'image/jpeg' } };
  const res = await model.generateContent([getVisionPrompt(), part]);
  const txt = res.response.text();
  const parsed = parseJsonResponse(txt);
  const defs = { description: '', hair_style: 'straight', hair_acc: 'none', makeup: 'natural', top_detail: 'basic top', material: 'cotton', outerwear: 'none', bottom_type: 'jeans', legwear: 'none', necklace: 'none', earrings: 'none', hand_acc: 'none', waist_acc: 'none', shoes: 'sneakers', scene: 'white studio', lighting: 'soft studio lighting', expression: 'gentle smile', style: 'casual' };
  return { success: true, data: { ...defs, ...parsed, rawResponse: txt } };
};

const analyzeWithGrok = async (img) => {
  const key = process.env.GROK_API_KEY;
  if (!key) throw new Error('GROK_API_KEY missing');
  const b64 = img.includes(',') ? img.split(',')[1] : img;
  const imgUrl = 'data:image/jpeg;base64,' + b64;
  try {
    const res = await axios.post('https://api.x.ai/v1/chat/completions', {
      messages: [{ role: 'user', content: [{ type: 'text', text: getVisionPrompt() }, { type: 'image_url', image_url: { url: imgUrl } }] }],
      model: 'grok-2-vision-latest',
      temperature: 0.1
    }, { headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' }, timeout: 60000 });
    const txt = res.data.choices[0]?.message?.content;
    if (!txt) throw new Error('No content');
    const parsed = parseJsonResponse(txt);
    const defs = { description: '', hair_style: 'straight', hair_acc: 'none', makeup: 'natural', top_detail: 'basic top', material: 'cotton', outerwear: 'none', bottom_type: 'jeans', legwear: 'none', necklace: 'none', earrings: 'none', hand_acc: 'none', waist_acc: 'none', shoes: 'sneakers', scene: 'white studio', lighting: 'soft studio lighting', expression: 'gentle smile', style: 'casual' };
    return { success: true, data: { ...defs, ...parsed, rawResponse: txt } };
  } catch (e) {
    throw e;
  }
};

const analyzeWithHuggingFace = async (img) => {
  const key = process.env.HUGGINGFACE_API_KEY;
  if (!key) throw new Error('HUGGINGFACE_API_KEY missing');
  const b64 = img.includes(',') ? img.split(',')[1] : img;
  const models = ['microsoft/git-large-coco', 'nlpconnect/vit-gpt2-image-captioning'];
  for (const m of models) {
    try {
      const res = await axios.post('https://api-inference.huggingface.co/models/' + m, { inputs: b64 }, { headers: { Authorization: 'Bearer ' + key }, timeout: 60000 });
      const txt = res.data[0]?.generated_text || res.data?.generated_text;
      if (txt) return { success: true, data: { description: txt, rawResponse: txt } };
    } catch (e) { continue; }
  }
  throw new Error('All HF failed');
};

const getPriority = () => (process.env.VISION_PROVIDER_PRIORITY || 'gemini,grok,huggingface').split(',').map(x => x.trim().toLowerCase());

export const analyzeImage = async (img, mime, opts = {}) => {
  const provs = getPriority();
  const errs = [];
  for (const p of provs) {
    try {
      if (p === 'gemini') return await analyzeWithGemini(img, mime, opts);
      if (p === 'grok') return await analyzeWithGrok(img);
      if (p === 'huggingface') return await analyzeWithHuggingFace(img);
    } catch (e) { errs.push(p + ': ' + e.message); }
  }
  return { success: false, error: 'All failed: ' + errs.join('; ') };
};

export default { analyzeImage };
