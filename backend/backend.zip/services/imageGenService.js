// Image Generation Service
// Providers: nano-banana, gemini-native, huggingface (Free), flow-fake

import axios from 'axios';
import { GoogleGenerativeAI } from '@google/generative-ai';

class ImageGenService {
  async generateImage({ prompt, provider = 'nano-banana', referenceImages = [], options = {} }) {
    // Mock Mode
    if (process.env.USE_FAKE_AI === '1' || provider === 'flow-fake') {
      return this._fakeImageResult(prompt, referenceImages);
    }

    // 1. Try Specified Provider
    if (provider === 'nano-banana') {
      try {
        return await this._generateWithNanoBanana(prompt, options);
      } catch (e) {
        console.warn(`[ImageGen] Nano Banana failed: ${e.message}. Trying fallback...`);
      }
    }

    if (provider === 'gemini-native') {
      try {
        return await this._generateWithGeminiNative(prompt, referenceImages, options);
      } catch (e) {
        console.warn(`[ImageGen] Gemini Native failed: ${e.message}. Trying fallback...`);
      }
    }

    // 2. Fallback to Hugging Face (Stable Diffusion)
    // This is a robust free alternative
    try {
      return await this._generateWithHuggingFace(prompt, options);
    } catch (e) {
      console.error(`[ImageGen] Hugging Face failed: ${e.message}`);
      // Final Fallback
      return this._fakeImageResult(prompt, referenceImages); // Return fake if everything fails
    }
  }

  // --- Nano Banana ---
  async _generateWithNanoBanana(prompt, options) {
    const apiKey = process.env.NANO_BANANA_API_KEY;
    if (!apiKey) throw new Error('NANO_BANANA_API_KEY missing');

    const response = await axios.post(
      'https://api.nanobanana.com/generate-image', // Replace with actual endpoint
      { text: prompt, ...options },
      { headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' } }
    );

    const imageUrl = response.data.imageUrl || response.data.url;
    if (!imageUrl) throw new Error('Invalid Nano Banana response');
    return { url: imageUrl, promptUsed: prompt };
  }

  // --- Gemini Native ---
  async _generateWithGeminiNative(prompt, referenceImages, options) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error('GEMINI_API_KEY missing');

    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash-exp' });

    // Gemini 2.0 Native (Text to Image support varies)
    const result = await model.generateContent(prompt);
    const text = result.response.text();
    
    // Try to find URL in text
    let url = text;
    const urlMatch = text.match(/"url":\s*"([^"]+)"/);
    if (urlMatch) url = urlMatch[1];
    
    return { url: url, promptUsed: prompt };
  }

  // --- Hugging Face Inference API (Stable Diffusion) ---
  async _generateWithHuggingFace(prompt, options) {
    const apiKey = process.env.HUGGINGFACE_API_KEY;
    if (!apiKey) throw new Error('HUGGINGFACE_API_KEY missing');

    // Using Stable Diffusion XL (Free Tier friendly)
    // Note: Free tier inference API can be slow.
    console.log('[ImageGen] Generating with Hugging Face (Stable Diffusion XL)...');

    const response = await axios.post(
      'https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0',
      { inputs: prompt },
      {
        headers: { Authorization: `Bearer ${apiKey}` },
        responseType: 'arraybuffer',
        timeout: 120000 // 120 seconds timeout for generation
      }
    );

    if (response.status !== 200) {
      throw new Error(`HF API Error: ${response.statusText}`);
    }

    // Convert binary image to base64
    const base64Image = Buffer.from(response.data, 'binary').toString('base64');
    const mimeType = 'image/png'; // SDXL usually outputs PNG
    return { url: `data:${mimeType};base64,${base64Image}`, promptUsed: prompt };
  }

  // --- FAKE (test mode) ---
  _fakeImageResult(prompt, referenceImages) {
    console.log('[ImageGenService] Fake mode - returning demo image');
    return {
      url: 'https://dummyimage.com/800x1200/cccccc/000000&text=Smart+Wardrobe+Demo',
      promptUsed: prompt,
      referenceImages,
    };
  }
}

export default new ImageGenService();
